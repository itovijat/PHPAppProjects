<?php include_once "head2.php"; ?>

<div class="content">
        <!-- Main content goes here -->

       
        



        













       

    </div>

    <?php include_once "foot.php"; ?>