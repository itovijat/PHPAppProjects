
<?php
include_once 'ih.php';
?>
       
    <h1 style="text-align: center;">You can buy coins here<br>1 Coin 1 Taka<br>Minimum 100 Coins</h1> 
    <h1 class="coming-soon" style="animation: blink 1s infinite; text-align: center;">Coming Soon</h1>
    


<?php
include_once 'if.php';
?>
