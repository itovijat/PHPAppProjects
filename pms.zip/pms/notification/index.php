<?php
if(isset($_REQUEST['msg'])){
$msg=$_REQUEST['msg'];

echo "<br><bR><center><h1>".$msg."</h1></center>";

}
?>